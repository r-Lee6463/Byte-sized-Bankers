package org.BSB.com.service;

import org.BSB.com.entity.Goal;
import org.BSB.com.entity.User;
import org.BSB.com.dto.GoalDto;
import java.util.List;

public interface GoalService {
    List<Goal> findGoalsByUser(User user);
    void createGoal(User user, GoalDto dto);
    void deleteGoalByIdAndUser(Long id, User user);
}
