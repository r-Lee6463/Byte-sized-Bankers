package org.BSB.com.service.impl;

import org.BSB.com.dto.GoalDto;
import org.BSB.com.entity.Goal;
import org.BSB.com.entity.User;
import org.BSB.com.repository.GoalRepository;
import org.BSB.com.service.GoalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class GoalServiceImpl implements GoalService {

    private final GoalRepository goalRepo;

    @Autowired
    public GoalServiceImpl(GoalRepository goalRepo) {
        this.goalRepo = goalRepo;
    }

    @Override
    public List<Goal> findGoalsByUser(User user) {
        return goalRepo.findByUser(user);
    }

    @Override
    @Transactional
    public void createGoal(User user, GoalDto dto) {
        Goal g = new Goal();
        g.setUser(user);
        g.setCategory(dto.getCategory());
        g.setLimitAmount(dto.getLimitAmount());
        goalRepo.save(g);
    }

    @Override
    @Transactional
    public void deleteGoalByIdAndUser(Long id, User user) {
        goalRepo.deleteByIdAndUser(id, user);
    }
}
