package org.BSB.com.service;

import org.BSB.com.entity.Goal;
import org.BSB.com.entity.User;
import org.BSB.com.repository.GoalRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
  
  @Service
  public class GoalService {
    private final GoalRepository repo;
    public GoalService(GoalRepository repo) { this.repo = repo; }
  
    public Goal save(Goal goal) { return repo.save(goal); }
    public List<Goal> findByUser(User u) { return repo.findByUser(u); }
    public Optional<Goal> findByUserAndCategory(User u, String cat) {
      return repo.findByUserAndCategory(u,cat);
    }
  }