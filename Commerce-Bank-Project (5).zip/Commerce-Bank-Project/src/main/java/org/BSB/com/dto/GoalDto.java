package org.BSB.com.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import java.math.BigDecimal;

public class GoalDto {

    @NotBlank(message = "Category is required")
    private String category;

    @DecimalMin(value = "0.01", message = "Limit must be positive")
    private BigDecimal limitAmount;

    // getters & setters
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public BigDecimal getLimitAmount() { return limitAmount; }
    public void setLimitAmount(BigDecimal limitAmount) { this.limitAmount = limitAmount; }
}