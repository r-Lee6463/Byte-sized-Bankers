package org.BSB.com.controller;

import jakarta.validation.Valid;
import org.BSB.com.dto.GoalDto;
import org.BSB.com.entity.Goal;
import org.BSB.com.entity.User;
import org.BSB.com.service.GoalService;
import org.BSB.com.service.UserService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/goals")
public class GoalsController {

    private final GoalService goalService;
    private final UserService userService;

    public GoalsController(GoalService goalService, UserService userService) {
        this.goalService = goalService;
        this.userService = userService;
    }

    @GetMapping
    public String listGoals(Model model, Principal principal) {
        User user = userService.findByEmail(principal.getName())
                        .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        List<Goal> goals = goalService.findByUser(user);
        model.addAttribute("goals", goals);
        model.addAttribute("goalDto", new GoalDto());
        return "goals";
    }

    @PostMapping
    public String createGoal(
            @Valid @ModelAttribute("goalDto") GoalDto goalDto,
            BindingResult result,
            Model model,
            Principal principal,
            RedirectAttributes ra
    ) {
        User user = userService.findByEmail(principal.getName())
                        .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        if (result.hasErrors()) {
            model.addAttribute("goals", goalService.findByUser(user));
            return "goals";
        }

        goalService.createGoal(user, goalDto);
        ra.addFlashAttribute("successMessage", "Goal added!");
        return "redirect:/goals";
    }
}