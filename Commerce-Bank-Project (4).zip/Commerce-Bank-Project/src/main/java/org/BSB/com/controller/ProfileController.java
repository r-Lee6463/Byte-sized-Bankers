package org.BSB.com.controller;

import jakarta.validation.Valid;
import org.BSB.com.dto.AccountUpdateDto;
import org.BSB.com.entity.User;
import org.BSB.com.service.StorageService;
import org.BSB.com.service.UserService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.security.Principal;

@Controller
@RequestMapping("/account")
public class ProfileController {

    private final UserService userService;
    private final StorageService storageService;

    public ProfileController(UserService userService,
                             StorageService storageService) {
        this.userService = userService;
        this.storageService = storageService;
    }

    // Show the account/profile page
    @GetMapping
    public String account(Model model, Principal principal) {
        User user = userService.findByEmail(principal.getName())
            .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        // Prepare the form‐backing dto
        AccountUpdateDto dto = new AccountUpdateDto();
        dto.setEmail(user.getEmail());
        // (you can set other fields on dto if needed)

        model.addAttribute("currentUser", user);
        model.addAttribute("accountUpdateDto", dto);
        return "account";   // resolves to account.html
    }

    // Handle profile updates (email, password, picture)
    @PostMapping
    public String updateAccount(
            @Valid @ModelAttribute("accountUpdateDto") AccountUpdateDto dto,
            BindingResult result,
            @RequestParam("profileImage") MultipartFile file,
            Model model,
            Principal principal
    ) {
        if (result.hasErrors()) {
            User user = userService.findByEmail(principal.getName())
                                   .orElseThrow();
            model.addAttribute("currentUser", user);
            return "account";
        }

        String filename = null;
        if (file != null && !file.isEmpty()) {
            filename = storageService.store(file);
        }

        userService.updateProfile(principal.getName(), dto, filename);
        return "redirect:/account?success";
    }
}
