package org.BSB.com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommerceBankApplication {
    public static void main(String[] args) {
        SpringApplication.run(CommerceBankApplication.class, args);
    }
}