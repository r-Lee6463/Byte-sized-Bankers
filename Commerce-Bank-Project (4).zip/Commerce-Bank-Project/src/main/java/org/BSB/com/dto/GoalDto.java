package org.BSB.com.dto;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

public class GoalDto {

    @NotBlank(message = "Category is required")
    private String category;

    @NotNull(message = "Limit is required")
    @DecimalMin(value = "0.01", message = "Limit must be positive")
    private BigDecimal limitAmount;

    // Getters & setters
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }

    public BigDecimal getLimitAmount() {
        return limitAmount;
    }
    public void setLimitAmount(BigDecimal limitAmount) {
        this.limitAmount = limitAmount;
    }
}
