package org.BSB.com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.BSB.com.entity.Transaction;
import org.BSB.com.entity.User;
import org.BSB.com.repository.TransactionRepository;

@Service
public class TransactionService {

    private final TransactionRepository repo;

    @Autowired
    public TransactionService(TransactionRepository repo) {
        this.repo = repo;
    }

    /** All transactions for a user */
    public List<Transaction> findByUser(User user) {
        return repo.findByUser(user);
    }

    /** Transactions for a user in a given category */
    public List<Transaction> findByUserAndCategory(User user, String category) {
        return repo.findByUserAndCategory(user, category);
    }

    /** Distinct categories this user has used */
    public List<String> getCategoriesForUser(User user) {
        return repo.findDistinctCategoriesByUser(user);
    }

    /** Save or update */
    public Transaction save(Transaction tx) {
        return repo.save(tx);
    }

    /** Optional: find by id */
    public Optional<Transaction> findById(Long id) {
        return repo.findById(id);
    }
}
