package org.BSB.com.controller;

import java.security.Principal;
import java.util.List;

import javax.validation.Valid;

import org.BSB.com.dto.GoalDto;
import org.BSB.com.entity.Goal;
import org.BSB.com.entity.User;
import org.BSB.com.service.GoalService;
import org.BSB.com.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class GoalController {

    private final GoalService goalService;
    private final UserService userService;

    @Autowired
    public GoalController(GoalService goalService, UserService userService) {
        this.goalService = goalService;
        this.userService = userService;
    }

    @GetMapping("/budget")
    public String viewBudget(Model model, Principal principal) {
        User u = userService.findByEmail(principal.getName())
                            .orElseThrow(() -> new RuntimeException("User not found"));
        List<Goal> goals = goalService.findByUser(u);
        model.addAttribute("goals", goals);
        model.addAttribute("currentUser", u);
        return "budgeting";
    }

    @GetMapping("/budget/add")
    public String showGoalForm(Model model) {
        model.addAttribute("goalDto", new GoalDto());
        return "add-goal";
    }

    @PostMapping("/budget/add")
    public String addGoal(
        @ModelAttribute("goalDto") @Valid GoalDto dto,
        BindingResult br,
        Principal principal
    ) {
        if (br.hasErrors()) {
            return "add-goal";
        }
        User u = userService.findByEmail(principal.getName())
                            .orElseThrow(() -> new RuntimeException("User not found"));
        Goal g = new Goal();
        g.setCategory(dto.getCategory());
        g.setLimitAmount(dto.getLimitAmount());
        g.setUser(u);
        goalService.save(g);
        return "redirect:/budget";
    }
}
